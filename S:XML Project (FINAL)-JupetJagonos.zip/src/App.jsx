// eslint-disable-next-line no-unused-vars
import React from 'react';
import { Desktop } from './components/Desktop'; // Ensure the path is correct

const App = () => {
    return (
        <div>
            <Desktop /> {/* Render the Desktop component */}
        </div>
    );
};

export default App;